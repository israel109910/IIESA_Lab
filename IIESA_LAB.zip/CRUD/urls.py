from django.urls import path
from .import views 


urlpatterns = [
    path('', views.main, name='main'),
    path('presion_manometrica/', views.presion_manometrica, name='presion_manometrica'),
    path('presion_manometrica/nuevo', views.crear_presion_manometrica, name='crear_presion_manometrica'),

    path('presion_diferencial/', views.presion_diferencial, name='presion_diferencial'),
    path('temperatura/', views.temperatura, name='temperatura'),
    path('flujo_vd/', views.flujo_volumetrico_dinamico, name='flujo_volumetrico_dinamico'),
    
    path('presion_manometrica/patrones', views.patrones_presion_manometrica, name='presion_manometrica_patrones'),
    path('presion_manometrica/patrones/detalles/<int:id>', views.detalles_patrones_presion_manometrica, name='detalles_presion_manometrica_patrones'),
    path('presion_manometrica/detalles/<int:id>', views.detalles, name='detalles'),
    path('presion_manometrica/detalles/<int:id>/editar', views.form_update, name='editar'),
    path('presion_manometrica/detalles/<int:id>/imprimir', views.imprimir, name='imprimir'),
    path('presion_manometrica/detalles/<int:id>/toma_datos', views.form_toma_datos, name='toma_datos'),
    path('presion_manometrica/detalles/<int:id>/calculos', views.calculos_pm, name='calculos'),


  
]
