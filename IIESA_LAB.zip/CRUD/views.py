from django.http import HttpResponse
from django.template import loader
import math
import pandas as pd
import os

from .models import PresionManometrica
from .models import PresionDiferencial
from .models import Temperatura
from .models import FlujoVolumetricoDinamico
from .models import PatronesPresionManometrica


from .forms import EditarForm
from .forms import TomaDatosManometricoForm
from .forms import PatronesPresionManometricaForm
from .forms import crearPresionManometricaForm

from django.shortcuts import render, redirect

from django.http import HttpResponseRedirect





def presion_manometrica(request):
  misfolios = PresionManometrica.objects.all().values().order_by('-id')
  template = loader.get_template('presion_manometrica.html')
  context = {
    'misfolios': misfolios,
  }
  return HttpResponse(template.render(context, request))
def crear_presion_manometrica(request):
  if request.method == 'POST':
        form = crearPresionManometricaForm(request.POST)
        if form.is_valid():
            # create a new `Band` and save it to the db
            folioPresionManometrica = form.save()
         
            return redirect('presion_manometrica')

  else:
        form = crearPresionManometricaForm()

  return render(request,
                'crear_presion_manometrica.html',
                {'form': form})
  
  
def presion_diferencial(request):
  misfolios = PresionDiferencial.objects.all().values()
  template = loader.get_template('presion_diferencial.html')
  context = {
    'misfolios': misfolios,
  }
  return HttpResponse(template.render(context, request))
def temperatura(request):
  misfolios = Temperatura.objects.all().values()
  template = loader.get_template('temperatura.html')
  context = {
    'misfolios': misfolios,
  }
  return HttpResponse(template.render(context, request))
def flujo_volumetrico_dinamico(request):
  misfolios = FlujoVolumetricoDinamico.objects.all().values()
  template = loader.get_template('flujo_volumetrico_dinamico.html')
  context = {
    'misfolios': misfolios,
  }
  return HttpResponse(template.render(context, request))

def main(request):
  template = loader.get_template('main.html')
  return HttpResponse(template.render())

def detalles(request, id):
  mifolio = PresionManometrica.objects.get(id=id)
  template = loader.get_template('detalles.html')
  context = {
    'mifolio': mifolio,
  }
  return HttpResponse(template.render(context, request))




  
#forms
  #form editar
def form_update(request, id):
    folio = PresionManometrica.objects.get(id=id)

    if request.method == 'POST':
        form = EditarForm(request.POST, instance=folio)
        if form.is_valid():
            # update the existing in the database
            form.save()
            # redirect to the detail page 
            return redirect('detalles', folio.id)
    else:
        form = EditarForm(instance=folio)

    return render(request,
                'editar.html',
                {'form': form})
    #form toma datos
def form_toma_datos(request, id):
    folio = PresionManometrica.objects.get(id=id)

    if request.method == 'POST':
        form = TomaDatosManometricoForm(request.POST, instance=folio)
        if form.is_valid():
            # update the existing in the database
            form.save()
            # redirect to the detail page 
            return redirect('detalles', folio.id)
    else:
        form = TomaDatosManometricoForm(instance=folio)

    return render(request,
                'toma_de_datos.html',
                {'form': form}
    )
  #imprimir certificado  
def imprimir(request, id):
  

  mifolio = PresionManometrica.objects.get(id=id)
  template = loader.get_template('imprimir.html')
  temperatura_amb_prom = (mifolio.ambientales_temperatura_inicial + mifolio.ambientales_temperatura_final)/2

  humedad_relativa_prom = (mifolio.ambientales_humedad_relativa_inicial+mifolio.ambientales_humedad_relativa_inicial)/2
  presion_barometrica_prom = (mifolio.ambientales_presion_barometrica_inicial + mifolio.ambientales_presion_barometrica_final)/2
  mipatron = PatronesPresionManometrica.objects.select_related('patron_identificacion', 'patron_intervalo_medida','patron_marca',
                                                               'patron_modelo','patron_no_serie','patron_certificado','patron_vigencia','patron_trazabilidad'
                                                               'patron_descripcion')
  
  
  context = {
    'temperatura_amb_prom' : temperatura_amb_prom,
    'presion_barometrica_prom' : presion_barometrica_prom,
    'mipatron': mipatron,
    'mifolio': mifolio,
    'humedad_relativa_prom': humedad_relativa_prom
    }
  
  return HttpResponse(template.render(context, request))


  
  
def calculos_pm(request, id):
    mifolio = PresionManometrica.objects.get(id=id)
    
    densidad_aceite=912
    curva_patron = PatronesPresionManometrica.objects.get(id=mifolio.patron_id_presion_manometrica_id)
    diferencia_altura = mifolio.ambientales_altura_patron-mifolio.ambientales_altura_IBC
    template = loader.get_template('calculos.html')
    latitud = mifolio.sitio_lat_degrees + mifolio.sitio_lat_minutes / 60 + mifolio.sitio_lat_seconds / 3600
    gravedad_local = (9.780318*(1+(0.0053024*(math.sin(math.pi*latitud/180)**2))-0.0000058*(math.sin(2*math.pi*latitud/180)**2))-(0.000003086*mifolio.sitio_altura))
    presion_columna = (912*gravedad_local*(mifolio.ambientales_altura_patron-mifolio.ambientales_altura_IBC))/1000
    temperatura_amb_prom = (mifolio.ambientales_temperatura_inicial + mifolio.ambientales_temperatura_final)/2
    #incertidumbre
    instrumento_resolucion_float = float(mifolio.instrumento_resolucion)
    incertidumbre_resolucion = instrumento_resolucion_float / math.sqrt(12)
    deriva_0_ibc_c1 = float(mifolio.desviacion_ciclo1_IBC)
    deriva_0_ibc_c2 = float(mifolio.desviacion_ciclo2_IBC)
    incertidumbre_deriva_0= (deriva_0_ibc_c1-deriva_0_ibc_c2)/ math.sqrt(3)
    incertidumbre_curva_patron = (curva_patron.ca_i_residuales)/math.sqrt(12)
    incertidumbre_curva_patron_error = (curva_patron.ca_residuales)/math.sqrt(12)
    deriva_patron =float(curva_patron.deriva)
    incertidumbre_deriva_patron = (deriva_patron)/(math.sqrt(12))
    incertidumbre_deriva_0_patron = (mifolio.desviacion_ciclo1_patron - mifolio.desviacion_ciclo1_patron)/math.sqrt(3)
    u_gravedad_local=(gravedad_local*0.0001)/(math.sqrt(3))
    u_densidad=(0.02851*densidad_aceite)
    u_diferencia_altura = (diferencia_altura)/(math.sqrt(12))
    u_PCOL = (math.sqrt(
    (gravedad_local * diferencia_altura * u_densidad)**2 +
    (densidad_aceite * diferencia_altura * u_gravedad_local)**2 +
    (gravedad_local * densidad_aceite * u_diferencia_altura)**2
    ))/1000

    
    context = {
      
        'presion_columna' : presion_columna,
        'gravedad_local': gravedad_local,
        'latitud' : latitud,
        'mifolio': mifolio,
        'temperatura_amb_prom':temperatura_amb_prom,
        'curva' : curva_patron,
        'ca_x10': curva_patron.ca_x10,
        'ca_x9': curva_patron.ca_x9,
        'ca_x8': curva_patron.ca_x8,
        'ca_x7': curva_patron.ca_x7,
        'ca_x6': curva_patron.ca_x6,
        'ca_x5': curva_patron.ca_x5,
        'ca_x4': curva_patron.ca_x4,
        'ca_x3': curva_patron.ca_x3,
        'ca_x2': curva_patron.ca_x2,
        'ca_x': curva_patron.ca_x,
        'ca_B': curva_patron.ca_B,
        
        'ca_i_x10': curva_patron.ca_i_x10,
        'ca_i_x9': curva_patron.ca_i_x9,
        'ca_i_x8': curva_patron.ca_i_x8,
        'ca_i_x7': curva_patron.ca_i_x7,
        'ca_i_x6': curva_patron.ca_i_x6,
        'ca_i_x5': curva_patron.ca_i_x5,
        'ca_i_x4': curva_patron.ca_i_x4,
        'ca_i_x3': curva_patron.ca_i_x3,
        'ca_i_x2': curva_patron.ca_i_x2,
        'ca_i_x': curva_patron.ca_i_x,
        'ca_i_B': curva_patron.ca_i_B,
        'incertidumbre_curva_patron' : incertidumbre_curva_patron,
        'incertidumbre_curva_patron_error' : incertidumbre_curva_patron_error,
        'incertidumbre_resolucion' : incertidumbre_resolucion,
        'incertidumbre_deriva_0': incertidumbre_deriva_0,
        'incertidumbre_deriva_patron' : incertidumbre_deriva_patron,
        'incertidumbre_deriva_0_patron' : incertidumbre_deriva_0_patron,
        'u_gravedad_local' : u_gravedad_local,
        'u_densidad' : u_densidad,
        'u_diferencia_altura' : u_diferencia_altura,
        'u_PCOL':u_PCOL,
        'u_reproducibilidad': curva_patron.reproducibilidad,
        

    }
  
    return HttpResponse(template.render(context, request))


def patrones_presion_manometrica(request):
  misfolios = PatronesPresionManometrica.objects.all().values()
  template = loader.get_template('patrones_pm.html')
  context = {
    'misfolios': misfolios,
  }
  return HttpResponse(template.render(context, request))

def detalles_patrones_presion_manometrica(request, id):
    # Fetch data from your model
    instance = PatronesPresionManometrica.objects.get(id=id)

    # If the request is POST, it means the form has been submitted
    if request.method == 'POST':
        form = PatronesPresionManometricaForm(request.POST, instance=instance)
        if form.is_valid():
            # Perform the necessary actions with the submitted data, e.g., update the database
            form.save()
    else:
        form = PatronesPresionManometricaForm(instance=instance)

    # Convert model instance data to dictionary
    data_dict = {
        field.name: getattr(instance, field.name) for field in instance._meta.fields
    }

    # Convert dictionary to DataFrame
    data = pd.DataFrame([data_dict])

    # Render DataFrame as HTML table with editable fields
    html_table = data.to_html(classes='table table-striped', index=False, escape=False, 
                              render_links=False, table_id='editable_table')

    context = {
        'html_table': html_table,
        'form': form,
    }

    return render(request, 'detalles_patron_pm.html', context)

#calcular error patron  
